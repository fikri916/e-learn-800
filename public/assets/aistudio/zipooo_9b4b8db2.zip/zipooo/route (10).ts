import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET /api/admin/professors?semesterId=...
export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const semesterId = sp.get("semesterId") || undefined;
  const professors = await db.professor.findMany({
    where: { ...(semesterId ? { semesterId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: {
      semester: { select: { id: true, name: true, nameAr: true, nameFr: true, academicYear: { select: { id: true, name: true, major: { select: { id: true, name: true, university: { select: { id: true, name: true } }, degreeLevel: { select: { id: true, name: true } } } } } } } },
      _count: { select: { lessons: true } },
    },
  });
  return NextResponse.json({ professors });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.semesterId) return NextResponse.json({ error: "semesterId required" }, { status: 400 });
  const p = await db.professor.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      bio: body.bio || null,
      bioAr: body.bioAr || null,
      bioFr: body.bioFr || null,
      photo: body.photo || null,
      email: body.email || null,
      semesterId: body.semesterId,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "PROFESSOR_CREATE", "Professor", p.id, p.name);
  return NextResponse.json({ ok: true, professor: p });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "bio", "bioAr", "bioFr", "photo", "email", "semesterId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const p = await db.professor.update({ where: { id }, data });
  await audit((session.user as any).id, "PROFESSOR_UPDATE", "Professor", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, professor: p });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.professor.delete({ where: { id } });
  await audit((session.user as any).id, "PROFESSOR_DELETE", "Professor", id, null);
  return NextResponse.json({ ok: true });
}
