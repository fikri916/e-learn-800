import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Get published lessons for a subject, optionally filtered by professor.
//  - When ?professorId is provided, returns only lessons by that professor.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const subjectId = sp.get("subjectId");
  if (!subjectId) return NextResponse.json({ lessons: [] });
  const professorId = sp.get("professorId");
  const lessons = await db.lesson.findMany({
    where: {
      subjectId,
      status: "PUBLISHED",
      ...(professorId ? { professorId } : {}),
    },
    orderBy: [{ order: "asc" }, { createdAt: "asc" }],
    select: {
      id: true, title: true, titleAr: true, titleFr: true,
      description: true, descriptionAr: true, descriptionFr: true,
      thumbnail: true, updatedAt: true, createdAt: true,
      order: true,
      _count: { select: { contentBlocks: true } },
    },
  });
  return NextResponse.json({ lessons });
}
