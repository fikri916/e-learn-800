import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET /api/admin/universities
export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const universities = await db.university.findMany({
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: { _count: { select: { majors: true, lessons: true, users: true } } },
  });
  return NextResponse.json({ universities });
}

// POST create
export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const u = await db.university.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      description: body.description || null,
      descriptionAr: body.descriptionAr || null,
      descriptionFr: body.descriptionFr || null,
      city: body.city || null,
      logo: body.logo || null,
      coverImage: body.coverImage || null,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  // Attach degrees if provided
  if (Array.isArray(body.degreeLevelIds)) {
    await db.degreeUniversity.deleteMany({ where: { universityId: u.id } });
    await db.degreeUniversity.createMany({
      data: body.degreeLevelIds.map((degreeLevelId: string) => ({ degreeLevelId, universityId: u.id })),
    });
  }
  await audit((session.user as any).id, "UNIVERSITY_CREATE", "University", u.id, u.name);
  return NextResponse.json({ ok: true, university: u });
}

// PATCH update
export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "description", "descriptionAr", "descriptionFr", "city", "logo", "coverImage"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const u = await db.university.update({ where: { id }, data });
  if (Array.isArray(rest.degreeLevelIds)) {
    await db.degreeUniversity.deleteMany({ where: { universityId: id } });
    if (rest.degreeLevelIds.length) {
      await db.degreeUniversity.createMany({
        data: rest.degreeLevelIds.map((degreeLevelId: string) => ({ degreeLevelId, universityId: id })),
      });
    }
  }
  await audit((session.user as any).id, "UNIVERSITY_UPDATE", "University", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, university: u });
}

// DELETE
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.university.delete({ where: { id } });
  await audit((session.user as any).id, "UNIVERSITY_DELETE", "University", id, null);
  return NextResponse.json({ ok: true });
}
