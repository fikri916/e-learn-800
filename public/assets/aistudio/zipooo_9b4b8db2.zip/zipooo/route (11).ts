import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const academicYearId = sp.get("academicYearId") || undefined;
  const semesters = await db.semester.findMany({
    where: { ...(academicYearId ? { academicYearId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: {
      academicYear: { select: { id: true, name: true, major: { select: { id: true, name: true, university: { select: { id: true, name: true } }, degreeLevel: { select: { id: true, name: true } } } } } },
      _count: { select: { subjects: true, lessons: true } },
    },
  });
  return NextResponse.json({ semesters });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.academicYearId) return NextResponse.json({ error: "academicYearId required" }, { status: 400 });
  const s = await db.semester.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      academicYearId: body.academicYearId,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "SEMESTER_CREATE", "Semester", s.id, s.name);
  return NextResponse.json({ ok: true, semester: s });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "academicYearId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const s = await db.semester.update({ where: { id }, data });
  await audit((session.user as any).id, "SEMESTER_UPDATE", "Semester", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, semester: s });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.semester.delete({ where: { id } });
  await audit((session.user as any).id, "SEMESTER_DELETE", "Semester", id, null);
  return NextResponse.json({ ok: true });
}
