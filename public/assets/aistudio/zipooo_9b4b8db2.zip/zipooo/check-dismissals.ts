import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const dismissals = await db.adDismissal.findMany({ include: { user: { select: { email: true } }, ad: { select: { title: true } } } });
console.log("AdDismissals:", JSON.stringify(dismissals, null, 2));
await db.$disconnect();
