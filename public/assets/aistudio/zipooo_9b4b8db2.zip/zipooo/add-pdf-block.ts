import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
async function main() {
  // Find the first lesson
  const lesson = await db.lesson.findFirst({ where: { status: "PUBLISHED" } });
  if (!lesson) { console.log("No published lesson found"); return; }
  console.log("Using lesson:", lesson.id, lesson.title);
  // Check if it already has a PDF block
  const existing = await db.lessonContentBlock.findFirst({ where: { lessonId: lesson.id, type: "pdf" } });
  if (existing) {
    console.log("Lesson already has a PDF block:", existing.id);
    await db.$disconnect();
    return;
  }
  // Use the existing test PDF in /uploads
  const pdfPath = "/uploads/2026-10/a2a548fe8712fc28.pdf";
  const block = await db.lessonContentBlock.create({
    data: {
      lessonId: lesson.id,
      order: 99,
      type: "pdf",
      title: "Lecture Notes — Poetry",
      content: null,
      mediaPath: pdfPath,
      downloadable: true,
    },
  });
  console.log("✓ Created PDF block:", block.id, "with path", pdfPath);
}
main().catch(console.error).finally(() => db.$disconnect());
