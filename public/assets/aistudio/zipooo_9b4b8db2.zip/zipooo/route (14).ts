import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const semesterId = sp.get("semesterId") || undefined;
  const subjects = await db.subject.findMany({
    where: { ...(semesterId ? { semesterId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: {
      semester: { select: { id: true, name: true, academicYear: { select: { id: true, name: true, major: { select: { id: true, name: true, university: { select: { id: true, name: true } }, degreeLevel: { select: { id: true, name: true } } } } } } } },
      _count: { select: { lessons: true } },
    },
  });
  return NextResponse.json({ subjects });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.semesterId) return NextResponse.json({ error: "semesterId required" }, { status: 400 });
  const s = await db.subject.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      description: body.description || null,
      descriptionAr: body.descriptionAr || null,
      descriptionFr: body.descriptionFr || null,
      coverImage: body.coverImage || null,
      semesterId: body.semesterId,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "SUBJECT_CREATE", "Subject", s.id, s.name);
  return NextResponse.json({ ok: true, subject: s });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "description", "descriptionAr", "descriptionFr", "coverImage", "semesterId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const s = await db.subject.update({ where: { id }, data });
  await audit((session.user as any).id, "SUBJECT_UPDATE", "Subject", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, subject: s });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.subject.delete({ where: { id } });
  await audit((session.user as any).id, "SUBJECT_DELETE", "Subject", id, null);
  return NextResponse.json({ ok: true });
}
