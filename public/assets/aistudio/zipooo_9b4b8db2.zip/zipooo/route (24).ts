import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// POST /api/public/dismiss-notif — record dismissal for current student
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const { notificationId } = await req.json();
  if (!notificationId) return NextResponse.json({ error: "id required" }, { status: 400 });
  const userId = (session.user as any).id;
  const existing = await db.notificationDismissal.findUnique({
    where: { userId_notificationId: { userId, notificationId } },
  });
  if (!existing) {
    await db.notificationDismissal.create({ data: { userId, notificationId } });
  }
  return NextResponse.json({ ok: true });
}
