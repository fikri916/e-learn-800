import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET degrees (all)
export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const degrees = await db.degreeLevel.findMany({
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: { _count: { select: { majors: true, lessons: true } } },
  });
  return NextResponse.json({ degrees });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const d = await db.degreeLevel.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  // Attach universities if provided
  if (Array.isArray(body.universityIds)) {
    await db.degreeUniversity.createMany({
      data: body.universityIds.map((universityId: string) => ({ degreeLevelId: d.id, universityId })),
    });
  }
  await audit((session.user as any).id, "DEGREE_CREATE", "DegreeLevel", d.id, d.name);
  return NextResponse.json({ ok: true, degree: d });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const d = await db.degreeLevel.update({ where: { id }, data });
  if (Array.isArray(rest.universityIds)) {
    await db.degreeUniversity.deleteMany({ where: { degreeLevelId: id } });
    if (rest.universityIds.length) {
      await db.degreeUniversity.createMany({
        data: rest.universityIds.map((universityId: string) => ({ degreeLevelId: id, universityId })),
      });
    }
  }
  await audit((session.user as any).id, "DEGREE_UPDATE", "DegreeLevel", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, degree: d });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.degreeLevel.delete({ where: { id } });
  await audit((session.user as any).id, "DEGREE_DELETE", "DegreeLevel", id, null);
  return NextResponse.json({ ok: true });
}
