import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/public/professors?semesterId=...&subjectId=...
//  - Always scoped to a semester (professor.semesterId).
//  - When ?subjectId is provided, returns only professors who have at least one
//    PUBLISHED lesson in this subject+semester (so the student picks a subject
//    first, then sees the professors teaching it).
//  - Returns the number of published lessons each professor has (overall, or in
//    the subject when subjectId is provided).
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const semesterId = sp.get("semesterId");
  if (!semesterId) return NextResponse.json({ professors: [] });
  const subjectId = sp.get("subjectId");

  // Derive the professor list from their published lessons when subjectId is set.
  if (subjectId) {
    const lessons = await db.lesson.findMany({
      where: { semesterId, subjectId, status: "PUBLISHED", professorId: { not: null } },
      select: {
        professor: {
          select: {
            id: true, name: true, nameAr: true, nameFr: true,
            bio: true, bioAr: true, bioFr: true,
            photo: true, email: true,
            published: true, order: true,
          },
        },
      },
      distinct: ["professorId"],
    });
    const professors = lessons
      .map((l) => l.professor)
      .filter((p) => p && p.published)
      .sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.name.localeCompare(b.name));
    // attach lesson count per professor in this subject+semester
    const withCounts = await Promise.all(professors.map(async (p: any) => {
      const c = await db.lesson.count({ where: { semesterId, subjectId, professorId: p.id, status: "PUBLISHED" } });
      return { ...p, _count: { lessons: c } };
    }));
    return NextResponse.json({ professors: withCounts });
  }

  // No subject filter — return all published professors in the semester.
  const professors = await db.professor.findMany({
    where: { semesterId, published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: {
      id: true, name: true, nameAr: true, nameFr: true,
      bio: true, bioAr: true, bioFr: true,
      photo: true, email: true,
      _count: { select: { lessons: { where: { status: "PUBLISHED" } } } },
    },
  });
  return NextResponse.json({ professors });
}
