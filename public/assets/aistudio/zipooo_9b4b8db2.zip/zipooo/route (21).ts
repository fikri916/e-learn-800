import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// PATCH /api/my-profile — student updates own profile (name + academic profile)
export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const body = await req.json();
  const userId = (session.user as any).id;
  const data: any = {};
  if (typeof body.name === "string") data.name = body.name;
  if ("universityId" in body) data.universityId = body.universityId === "" ? null : body.universityId;
  if ("degreeLevelId" in body) data.degreeLevelId = body.degreeLevelId === "" ? null : body.degreeLevelId;
  if ("majorId" in body) data.majorId = body.majorId === "" ? null : body.majorId;
  if ("academicYearId" in body) data.academicYearId = body.academicYearId === "" ? null : body.academicYearId;
  const u = await db.user.update({ where: { id: userId }, data });
  return NextResponse.json({ ok: true, user: u });
}
