# Generate two PNG banners: mobile (600x300) + desktop (1600x400)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Mobile banner
fig, ax = plt.subplots(figsize=(6, 3), dpi=100)
ax.set_xlim(0, 6); ax.set_ylim(0, 3)
ax.add_patch(patches.Rectangle((0, 0), 6, 3, facecolor="#1e3a8a", edgecolor="none"))
ax.text(3, 1.7, "MOBILE BANNER", ha="center", va="center", color="white", fontsize=22, fontweight="bold")
ax.text(3, 1.1, "600 × 300 px", ha="center", va="center", color="#bfdbfe", fontsize=14)
ax.text(3, 0.5, "phone browsing", ha="center", va="center", color="#dbeafe", fontsize=11, style="italic")
ax.axis("off")
plt.tight_layout(pad=0)
plt.savefig("/tmp/banner-mobile.png", bbox_inches="tight", pad_inches=0, dpi=100)
plt.close()

# Desktop banner
fig, ax = plt.subplots(figsize=(16, 4), dpi=100)
ax.set_xlim(0, 16); ax.set_ylim(0, 4)
ax.add_patch(patches.Rectangle((0, 0), 16, 4, facecolor="#0f766e", edgecolor="none"))
ax.text(8, 2.3, "DESKTOP BANNER", ha="center", va="center", color="white", fontsize=32, fontweight="bold")
ax.text(8, 1.5, "1600 × 400 px", ha="center", va="center", color="#a7f3d0", fontsize=20)
ax.text(8, 0.7, "laptop browsing", ha="center", va="center", color="#d1fae5", fontsize=14, style="italic")
ax.axis("off")
plt.tight_layout(pad=0)
plt.savefig("/tmp/banner-desktop.png", bbox_inches="tight", pad_inches=0, dpi=100)
plt.close()
print("OK")
