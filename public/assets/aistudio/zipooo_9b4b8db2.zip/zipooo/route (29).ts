import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/public/majors?universityId=...&degreeLevelId=...&facultyId=...
// Filters majors by university + degree (+ optional faculty).
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const universityId = sp.get("universityId");
  const degreeLevelId = sp.get("degreeLevelId");
  const facultyId = sp.get("facultyId");
  if (!universityId || !degreeLevelId) return NextResponse.json({ majors: [] });
  const majors = await db.major.findMany({
    where: {
      universityId,
      degreeLevelId,
      published: true,
      ...(facultyId ? { facultyId } : {}),
    },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: { id: true, name: true, nameAr: true, nameFr: true, description: true, descriptionAr: true, descriptionFr: true, coverImage: true, facultyId: true },
  });
  return NextResponse.json({ majors });
}
