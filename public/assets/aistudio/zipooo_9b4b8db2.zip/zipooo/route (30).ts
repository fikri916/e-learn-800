// Get current session user + academic profile
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ user: null });
  const u = await db.user.findUnique({
    where: { id: (session.user as any).id },
    select: {
      id: true, email: true, name: true, role: true, status: true,
      universityId: true, degreeLevelId: true, majorId: true, academicYearId: true,
      university: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      major: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      academicYear: { select: { id: true, name: true, nameAr: true, nameFr: true } },
    },
  });
  if (!u) return NextResponse.json({ user: null });
  if (u.status === "SUSPENDED") return NextResponse.json({ user: null, error: "suspended" });
  return NextResponse.json({ user: u });
}
