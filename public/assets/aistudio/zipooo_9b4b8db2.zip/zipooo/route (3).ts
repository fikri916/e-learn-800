// GET /api/admin/backup — exports ALL website data as a single downloadable JSON file.
// Includes every database table (users, universities, faculties, degrees, majors, years,
// semesters, subjects, professors, lessons, lesson content blocks, media file metadata,
// notifications, ads, favorites, recently viewed, website settings, audit logs).
// Also embeds media file bytes (base64) for files smaller than 50 MB so the backup
// is fully self-contained — restoring it puts everything back in place.

import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { readFile, stat } from "fs/promises";
import path from "path";

const MAX_EMBED_BYTES = 50 * 1024 * 1024; // 50 MB per file — larger files only get metadata

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  // Pull every table in parallel for speed
  const [
    users, universities, faculties, degreeLevels, degreeUniversities,
    majors, academicYears, semesters, subjects, professors, lessons,
    lessonContentBlocks, mediaFiles, notifications, notificationDismissals,
    favorites, recentlyViewed, websiteSettings, auditLogs,
    ads, adDismissals,
  ] = await Promise.all([
    db.user.findMany(),
    db.university.findMany(),
    db.faculty.findMany(),
    db.degreeLevel.findMany(),
    db.degreeUniversity.findMany(),
    db.major.findMany(),
    db.academicYear.findMany(),
    db.semester.findMany(),
    db.subject.findMany(),
    db.professor.findMany(),
    db.lesson.findMany(),
    db.lessonContentBlock.findMany(),
    db.mediaFile.findMany(),
    db.notification.findMany(),
    db.notificationDismissal.findMany(),
    db.favorite.findMany(),
    db.recentlyViewed.findMany(),
    db.websiteSettings.findMany(),
    db.auditLog.findMany(),
    db.ad.findMany(),
    db.adDismissal.findMany(),
  ]);

  // Embed media file bytes as base64 (only for files smaller than MAX_EMBED_BYTES)
  const mediaBlobs: Record<string, string> = {};
  const skippedFiles: { path: string; size: number; reason: string }[] = [];
  await Promise.all(mediaFiles.map(async (m) => {
    if (!m.path || !m.path.startsWith("/uploads/")) return;
    try {
      const abs = path.join(process.cwd(), "public", m.path);
      const info = await stat(abs);
      if (info.size > MAX_EMBED_BYTES) {
        skippedFiles.push({ path: m.path, size: info.size, reason: "too_large" });
        return;
      }
      const buf = await readFile(abs);
      mediaBlobs[m.path] = buf.toString("base64");
    } catch (e: any) {
      skippedFiles.push({ path: m.path, size: m.size, reason: "missing_on_disk" });
    }
  }));

  const backup = {
    version: 1,
    timestamp: new Date().toISOString(),
    tables: {
      users,
      universities,
      faculties,
      degreeLevels,
      degreeUniversities,
      majors,
      academicYears,
      semesters,
      subjects,
      professors,
      lessons,
      lessonContentBlocks,
      mediaFiles,
      notifications,
      notificationDismissals,
      favorites,
      recentlyViewed,
      websiteSettings,
      auditLogs,
      ads,
      adDismissals,
    },
    mediaBlobs,
    skippedFiles,
  };

  // Return as a downloadable JSON attachment
  const filename = `e-learning-backup-${new Date().toISOString().slice(0, 10)}.json`;
  return new NextResponse(JSON.stringify(backup, null, 2), {
    status: 200,
    headers: {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
    },
  });
}
