import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET /api/admin/stats — dashboard statistics
export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const [
    totalUsers, totalStudents, totalUniversities, totalMajors,
    totalYears, totalSemesters, totalSubjects, totalPublishedLessons,
    totalLessons, totalMedia, totalActiveNotifications, recentRegistrations,
    recentLessons,
  ] = await Promise.all([
    db.user.count(),
    db.user.count({ where: { role: "STUDENT" } }),
    db.university.count(),
    db.major.count(),
    db.academicYear.count(),
    db.semester.count(),
    db.subject.count(),
    db.lesson.count({ where: { status: "PUBLISHED" } }),
    db.lesson.count(),
    db.mediaFile.count(),
    db.notification.count({ where: { status: "PUBLISHED" } }),
    db.user.findMany({ orderBy: { createdAt: "desc" }, take: 8, select: { id: true, name: true, email: true, createdAt: true, role: true, status: true } }),
    db.lesson.findMany({ orderBy: { createdAt: "desc" }, take: 8, include: { subject: { select: { name: true } } } }),
  ]);

  return NextResponse.json({
    stats: {
      totalUsers, totalStudents, totalUniversities, totalMajors,
      totalYears, totalSemesters, totalSubjects, totalPublishedLessons,
      totalLessons, totalMedia, totalActiveNotifications,
      recentRegistrations, recentLessons,
    },
  });
}
