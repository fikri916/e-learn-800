import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const settings = await db.websiteSettings.findFirst();
  return NextResponse.json({ settings });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  // Get or create singleton
  let settings = await db.websiteSettings.findFirst();
  if (!settings) {
    settings = await db.websiteSettings.create({ data: {} });
  }
  const data: any = {};
  for (const k of ["name", "logo", "coverImage", "description", "defaultLanguage", "defaultTheme", "enabledLanguages", "contactEmail", "footerText"]) {
    if (k in body) data[k] = body[k] === "" ? null : body[k];
  }
  if ("allowPublicDirectory" in body) data.allowPublicDirectory = !!body.allowPublicDirectory;
  const updated = await db.websiteSettings.update({ where: { id: settings.id }, data });
  await audit((session.user as any).id, "SETTINGS_UPDATE", "WebsiteSettings", settings.id, JSON.stringify(data));
  return NextResponse.json({ ok: true, settings: updated });
}
