import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// Toggle favorite (POST) / list favorites (GET)
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const favorites = await db.favorite.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { createdAt: "desc" },
    include: {
      lesson: {
        select: {
          id: true, title: true, titleAr: true, titleFr: true,
          description: true, thumbnail: true,
          subject: { select: { id: true, name: true } },
        },
      },
    },
  });
  return NextResponse.json({ favorites });
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const { lessonId, action } = await req.json();
  if (!lessonId) return NextResponse.json({ error: "lessonId required" }, { status: 400 });
  const userId = (session.user as any).id;
  if (action === "remove") {
    await db.favorite.deleteMany({ where: { userId, lessonId } });
    return NextResponse.json({ ok: true, favorite: false });
  }
  // toggle
  const existing = await db.favorite.findUnique({
    where: { userId_lessonId: { userId, lessonId } },
  });
  if (existing) {
    await db.favorite.delete({ where: { id: existing.id } });
    return NextResponse.json({ ok: true, favorite: false });
  } else {
    await db.favorite.create({ data: { userId, lessonId } });
    return NextResponse.json({ ok: true, favorite: true });
  }
}
