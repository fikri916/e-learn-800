import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/public/degrees?universityId=...&facultyId=...
//  - If facultyId is provided: returns degree levels that have at least one
//    PUBLISHED major in (universityId, facultyId).
//  - Otherwise: returns all degree levels offered at the university (via the
//    DegreeUniversity join — used by the admin MajorDialog and other places
//    that don't have a faculty context).
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const universityId = sp.get("universityId");
  const facultyId = sp.get("facultyId");
  if (!universityId) return NextResponse.json({ degrees: [] });

  if (facultyId) {
    // Find majors in (university, faculty) and gather the distinct degree levels
    const majors = await db.major.findMany({
      where: { universityId, facultyId, published: true },
      select: { degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true, published: true, order: true } } },
    });
    const seen = new Map<string, any>();
    for (const m of majors) {
      const d = m.degreeLevel;
      if (d && d.published && !seen.has(d.id)) seen.set(d.id, d);
    }
    const degrees = Array.from(seen.values()).sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.name.localeCompare(b.name));
    return NextResponse.json({ degrees });
  }

  // No faculty filter — fall back to the DegreeUniversity join
  const joins = await db.degreeUniversity.findMany({
    where: { universityId },
    include: { degreeLevel: true },
    orderBy: { degreeLevel: { order: "asc" } },
  });
  return NextResponse.json({
    degrees: joins
      .map((j) => j.degreeLevel)
      .filter((d) => d.published)
      .map((d) => ({ id: d.id, name: d.name, nameAr: d.nameAr, nameFr: d.nameFr })),
  });
}
