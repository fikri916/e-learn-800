// File upload API — multipart upload with progress on client, persistent local storage.
// Files live in /home/z/my-project/public/uploads/<year-month>/<cuid>.<ext>
// The same Next.js process serves /public at runtime, so files are reachable via /uploads/...

import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";

const UPLOAD_DIR = path.join(process.cwd(), "public", "uploads");

// Allowed MIME / extensions and size limits
const ALLOWED: Record<string, { ext: string; type: string; maxSize: number; kind: string }> = {
  "application/pdf": { ext: "pdf", type: "application/pdf", maxSize: 200 * 1024 * 1024, kind: "pdf" },
  "video/mp4": { ext: "mp4", type: "video/mp4", maxSize: 500 * 1024 * 1024, kind: "video" },
  "video/webm": { ext: "webm", type: "video/webm", maxSize: 500 * 1024 * 1024, kind: "video" },
  "video/quicktime": { ext: "mov", type: "video/quicktime", maxSize: 500 * 1024 * 1024, kind: "video" },
  "image/jpeg": { ext: "jpg", type: "image/jpeg", maxSize: 25 * 1024 * 1024, kind: "image" },
  "image/jpg": { ext: "jpg", type: "image/jpeg", maxSize: 25 * 1024 * 1024, kind: "image" },
  "image/png": { ext: "png", type: "image/png", maxSize: 25 * 1024 * 1024, kind: "image" },
  "image/webp": { ext: "webp", type: "image/webp", maxSize: 25 * 1024 * 1024, kind: "image" },
  "image/gif": { ext: "gif", type: "image/gif", maxSize: 25 * 1024 * 1024, kind: "image" },
  "application/msword": { ext: "doc", type: "application/msword", maxSize: 50 * 1024 * 1024, kind: "document" },
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
    ext: "docx", type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", maxSize: 50 * 1024 * 1024, kind: "document"
  },
  "application/vnd.ms-excel": { ext: "xls", type: "application/vnd.ms-excel", maxSize: 50 * 1024 * 1024, kind: "document" },
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
    ext: "xlsx", type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", maxSize: 50 * 1024 * 1024, kind: "document"
  },
  "application/zip": { ext: "zip", type: "application/zip", maxSize: 100 * 1024 * 1024, kind: "document" },
  "text/plain": { ext: "txt", type: "text/plain", maxSize: 5 * 1024 * 1024, kind: "document" },
};

async function ensureAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function POST(req: NextRequest) {
  const session = await ensureAdmin();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  try {
    const formData = await req.formData();
    const file = formData.get("file");
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }
    const allowed = ALLOWED[file.type];
    if (!allowed) {
      return NextResponse.json({ error: "invalid_type", message: `MIME type ${file.type} not allowed` }, { status: 415 });
    }
    if (file.size > allowed.maxSize) {
      return NextResponse.json({ error: "too_large", message: `Max ${allowed.maxSize} bytes` }, { status: 413 });
    }
    // Ensure dir exists
    const now = new Date();
    const ym = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}`;
    const dirPath = path.join(UPLOAD_DIR, ym);
    await mkdir(dirPath, { recursive: true });
    const id = randomBytes(8).toString("hex");
    const filename = `${id}.${allowed.ext}`;
    const filePath = path.join(dirPath, filename);
    const buffer = Buffer.from(await file.arrayBuffer());
    await writeFile(filePath, buffer);
    const publicPath = `/uploads/${ym}/${filename}`;

    // Save to media library
    const media = await db.mediaFile.create({
      data: {
        filename,
        originalName: file.name,
        path: publicPath,
        mimeType: allowed.type,
        size: file.size,
        type: allowed.kind,
      },
    });
    return NextResponse.json({ ok: true, media });
  } catch (e: any) {
    return NextResponse.json({ error: "server_error", message: String(e?.message || e) }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const session = await ensureAdmin();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const sp = req.nextUrl.searchParams;
  const type = sp.get("type") || undefined;
  const q = sp.get("q") || undefined;
  const media = await db.mediaFile.findMany({
    where: {
      ...(type ? { type } : {}),
      ...(q ? { originalName: { contains: q } } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({ media });
}

export async function DELETE(req: NextRequest) {
  const session = await ensureAdmin();
  if (!session) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const media = await db.mediaFile.findUnique({ where: { id } });
  if (!media) return NextResponse.json({ error: "not found" }, { status: 404 });
  await db.mediaFile.delete({ where: { id } });
  // Best-effort delete from disk
  try {
    const fs = await import("fs/promises");
    const abs = path.join(process.cwd(), "public", media.path);
    await fs.unlink(abs);
  } catch {}
  return NextResponse.json({ ok: true });
}
