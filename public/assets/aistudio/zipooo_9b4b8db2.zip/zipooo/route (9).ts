import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const notifications = await db.notification.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
  });
  return NextResponse.json({ notifications });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.title || !body.content) return NextResponse.json({ error: "title+content required" }, { status: 400 });
  const n = await db.notification.create({
    data: {
      title: body.title,
      content: body.content,
      imageUrl: body.imageUrl || null,
      audienceType: body.audienceType || "ALL",
      targetIds: body.targetIds ? JSON.stringify(body.targetIds) : null,
      showEveryVisit: !!body.showEveryVisit,
      status: body.status || "DRAFT",
      publishAt: body.publishAt ? new Date(body.publishAt) : null,
      expiresAt: body.expiresAt ? new Date(body.expiresAt) : null,
    },
  });
  await audit((session.user as any).id, "NOTIF_CREATE", "Notification", n.id, n.title);
  return NextResponse.json({ ok: true, notification: n });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["title", "content", "imageUrl", "audienceType", "status"]) {
    if (k in rest) data[k] = rest[k];
  }
  if ("showEveryVisit" in rest) data.showEveryVisit = !!rest.showEveryVisit;
  if (rest.targetIds !== undefined) data.targetIds = rest.targetIds ? JSON.stringify(rest.targetIds) : null;
  if (rest.publishAt !== undefined) data.publishAt = rest.publishAt ? new Date(rest.publishAt) : null;
  if (rest.expiresAt !== undefined) data.expiresAt = rest.expiresAt ? new Date(rest.expiresAt) : null;
  const n = await db.notification.update({ where: { id }, data });
  await audit((session.user as any).id, "NOTIF_UPDATE", "Notification", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, notification: n });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.notification.delete({ where: { id } });
  await audit((session.user as any).id, "NOTIF_DELETE", "Notification", id, null);
  return NextResponse.json({ ok: true });
}
