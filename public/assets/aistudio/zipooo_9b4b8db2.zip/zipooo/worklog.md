# Worklog: دليل University E-Learning Platform

Project: Full-stack Next.js 16 university learning platform (single-page architecture on `/` route, with API routes).

---
Task ID: 0
Agent: main (Z.ai)
Task: Project initialization and architecture planning

Work Log:
- Loaded fullstack-dev skill, ran init script (Next.js 16 + Tailwind 4 + shadcn/ui + Prisma SQLite + NextAuth + next-themes + next-intl already available)
- Read existing schema, layout, globals.css
- Decided architecture: client-side SPA on `/` route (sandbox constraint), hash-based routing via Zustand, all data via API routes
- Decided stack: NextAuth credentials + bcrypt, local persistent file storage under `public/uploads`, Prisma SQLite

Stage Summary:
- Foundation ready. Building schema, auth, i18n, theming, layout, then student + admin views.

---
Task ID: 1
Agent: main (Z.ai)
Task: Build the entire application — schema, auth, APIs, SPA router, student views, admin dashboard

Work Log:
- Defined full Prisma schema: User, Account, Session, VerificationToken, University, Faculty, DegreeLevel, DegreeUniversity, Major, AcademicYear, Semester, Subject, Lesson, LessonContentBlock, MediaFile, Notification, NotificationDismissal, Favorite, RecentlyViewed, WebsiteSettings, AuditLog
- Pushed schema to SQLite database, generated Prisma client
- Auth: NextAuth credentials provider with bcrypt password hashing, JWT sessions, admin role check on every protected route, "fikriad" username alias support
- Built file upload API at /api/upload with multipart form, type/size validation, persistent storage under /public/uploads/<year-month>/<hex>.<ext>, MediaFile record auto-created
- Seed script: created admin user (fikriad@dalil.local / fikri@31048410@), website settings, demo academic structure (Cadi Ayyad University → Licence → English Studies → 3 years → 6 semesters → 3 subjects → 4 published lessons), welcome notification
- i18n: full dictionaries for ar/fr/en (~250 keys each), RTL detection, <html dir/lang> syncing via HtmlLangDir component, persisted choice via Zustand+localStorage
- Theme: next-themes provider with light/dark/system, persisted, applied via class="dark" strategy
- SPA router: Zustand store with hashchange listener, navigate/back/hydrate; pattern /u/<id>/d/<id>/m/<id>/y/<id>/s/<id>/sub/<id> + /lesson/<id> + /admin/<section>
- Header: logo, search bar, language switcher, theme toggle, profile dropdown (dashboard/profile/admin/logout), notification bell, mobile menu
- Footer: site name + about + contact + Instagram credit link "made by fikriadarmouch" pointing to https://www.instagram.com/fikriadarmouch/ with target=_blank rel=noopener noreferrer
- Student views: Home (hero + stats + university preview), Universities directory (search), Degrees/Majors/Years/Semesters/Subjects/Lessons listings, Lesson view (breadcrumb, content blocks renderer, prev/next/related, favorite toggle, academic context), Sign In/Up (with dependent dropdowns), Dashboard (welcome, quick links, recently viewed, favorites, subjects from profile), Profile (academic info + password change), Notifications center, Search results (across universities/majors/subjects/lessons)
- Lesson content renderer: text, notes, PDF (inline iframe preview + download), uploaded videos (HTML5 player), YouTube embeds (URL extraction), images, image galleries (with thumbnails), file downloads, external links
- Admin shell: sticky sidebar with all 16 sections, responsive (mobile sheet), header with language/theme/profile, footer with Instagram credit
- Admin views: Overview (9 stat cards + recent registrations + recent lessons), Users (searchable/filterable table + edit dialog with role/status/academic profile + delete), Universities (CRUD + degree assignment + logo/cover/descriptions in 3 langs), Faculties (CRUD per university), Degrees (CRUD + university assignment), Majors (CRUD + filtered by university/degree), Years (CRUD + filtered by major), Semesters (CRUD + filtered by year), Subjects (CRUD + filtered by semester + lesson count), Lessons (CRUD with dependent dropdowns university→degree→major→year→semester→subject, content blocks editor with 9 types: text/notes/pdf/video/youtube/image/gallery/file/link, drag-style reorder, status draft/published/unpublished/archived, server-side chain validation), Media (library + upload dropzone + filter by type + copy path + delete), Notifications (CRUD with audience targeting ALL/UNIVERSITY/DEGREE/MAJOR/YEAR/USERS, publish/expiry dates, show-every-visit flag), Branding (site name/logo/cover/description/footer/contact), Settings (default language/theme/enabled langs/public directory), Security (change own password + last-admin protection), Audit Logs (table with action/entity/user/created/details)
- API routes: /api/auth/[...nextauth], /api/auth/register, /api/auth/password, /api/upload (POST/GET/DELETE), /api/public/{me,universities,degrees,majors,years,semesters,subjects,lessons,lesson,search,favorite,recently-viewed,notifications,website,dismiss-notif}, /api/admin/{stats,users,universities,faculties,degrees,majors,years,semesters,subjects,lessons,media,notifications,settings,audit}, /api/my-profile
- Server-side validation in lesson API: validateChain ensures subject→semester→year→major→degree→university relationships all match before saving
- Audit log: every privileged admin operation recorded with userId/action/entity/entityId/details
- Last-admin protection: prevents the only remaining admin from being deleted or demoted

Stage Summary:
- All 24 acceptance criteria from the original prompt implemented and verified.
- Browser-verified end-to-end:
  ✓ Home page loads with hero, university cards, footer credit
  ✓ Footer credit link points to https://www.instagram.com/fikriadarmouch/ with target=_blank rel=noopener noreferrer
  ✓ Language switching works: Arabic RTL + French LTR + English LTR
  ✓ Theme toggle works: light/dark/system, persisted across reload
  ✓ Anonymous student can register, sign in, sign out
  ✓ Academic navigation works end-to-end: Universities → Degrees → Majors → Years → Semesters → Subjects → Lessons
  ✓ Lesson view renders text + YouTube embed + has Add-to-Favorites + prev/next/related
  ✓ Favorites appear on student dashboard after marking
  ✓ Student dashboard shows welcome, university/major/year badges, recently viewed, favorites, subjects from profile
  ✓ Search returns matching lessons
  ✓ Admin login (fikriad / fikri@31048410@) works, redirects to /admin/overview
  ✓ Non-admin user blocked from /admin/* routes
  ✓ Admin sidebar shows all 16 sections
  ✓ Admin overview shows live stats from database
  ✓ Admin lessons page has working dependent dropdowns (university filters degrees filters majors…)
  ✓ Admin can upload PDF via drag-and-drop / file picker; file persists after refresh
  ✓ Admin settings save persists across reload
  ✓ Audit logs capture admin actions
  ✓ All routes render without console errors
- Files produced:
  - /home/z/my-project/.env.example
  - /home/z/my-project/scripts/seed.ts (re-runnable admin + demo data seeding)
  - /home/z/my-project/scripts/check-data.ts (utility to inspect DB)
  - /home/z/my-project/download/admin-overview.png, admin-dark.png, admin-final.png, student-dashboard.png, home-arabic.png
