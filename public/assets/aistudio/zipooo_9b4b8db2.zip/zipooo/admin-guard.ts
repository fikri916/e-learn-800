// Server-side admin authorization helper
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

export async function requireAdmin() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "ADMIN") return null;
  return session;
}

export async function audit(
  userId: string | undefined,
  action: string,
  entity: string,
  entityId: string | null = null,
  details: string | null = null
) {
  try {
    await db.auditLog.create({
      data: { userId: userId || null, action, entity, entityId, details },
    });
  } catch (e) {
    console.error("[audit] failed:", e);
  }
}
