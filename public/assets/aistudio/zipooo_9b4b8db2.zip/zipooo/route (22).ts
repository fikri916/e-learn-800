import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// GET /api/public/ads?type=POPUP|HERO_BANNER
// Returns active ads for the current user, respecting audience targeting,
// publish/expiry window, and dismissal state (for POPUP).
export async function GET(req: Request) {
  const sp = new URL(req.url).searchParams;
  const type = sp.get("type") || undefined;
  const now = new Date();

  // Active = PUBLISHED + within publish/expiry window
  const all = await db.ad.findMany({
    where: {
      status: "PUBLISHED",
      ...(type ? { type } : {}),
      AND: [
        { OR: [{ publishAt: null }, { publishAt: { lte: now } }] },
        { OR: [{ expiresAt: null }, { expiresAt: { gte: now } }] },
      ],
    },
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    take: 50,
  });

  // Resolve current user (if any) for audience filtering
  const session = await getServerSession(authOptions);
  let userId: string | null = null;
  let user: any = null;
  if (session) {
    userId = (session.user as any).id;
    user = await db.user.findUnique({
      where: { id: userId },
      select: { universityId: true, degreeLevelId: true, majorId: true, academicYearId: true },
    });
  }

  // Audience filtering
  const visible = all.filter((ad) => {
    if (ad.audienceType === "ALL") return true;
    if (!userId || !user) return false;
    if (ad.audienceType === "USERS") {
      const ids: string[] = ad.targetIds ? JSON.parse(ad.targetIds) : [];
      return ids.includes(userId);
    }
    if (!ad.targetIds) return false;
    const ids: string[] = JSON.parse(ad.targetIds);
    if (ad.audienceType === "UNIVERSITY") return user.universityId && ids.includes(user.universityId);
    if (ad.audienceType === "DEGREE") return user.degreeLevelId && ids.includes(user.degreeLevelId);
    if (ad.audienceType === "MAJOR") return user.majorId && ids.includes(user.majorId);
    if (ad.audienceType === "YEAR") return user.academicYearId && ids.includes(user.academicYearId);
    return false;
  });

  // For POPUP ads: filter out dismissed ones unless showEveryLogin
  let dismissed = new Set<string>();
  if (userId) {
    const ds = await db.adDismissal.findMany({
      where: { userId },
      select: { adId: true },
    });
    dismissed = new Set(ds.map((d) => d.adId));
  }
  const visibleNotDismissed = visible.filter((ad) => {
    if (ad.type === "POPUP" && !ad.showEveryLogin && dismissed.has(ad.id)) return false;
    return true;
  });

  return NextResponse.json({ ads: visibleNotDismissed });
}

// POST /api/public/ads — dismiss a popup ad for current user
export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const { adId } = await req.json();
  if (!adId) return NextResponse.json({ error: "adId required" }, { status: 400 });
  const userId = (session.user as any).id;
  const existing = await db.adDismissal.findUnique({
    where: { userId_adId: { userId, adId } },
  });
  if (!existing) {
    await db.adDismissal.create({ data: { userId, adId } });
  }
  return NextResponse.json({ ok: true });
}
