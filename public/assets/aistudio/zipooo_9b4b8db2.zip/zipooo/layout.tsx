import type { Metadata } from "next";
import { Geist, Geist_Mono, Cairo } from "next/font/google";
import "./globals.css";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// Cairo is a modern Arabic typeface from Google Fonts.
// We expose it as the CSS variable --font-cairo and apply it to <body> when html[lang="ar"].
const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "e-learning — University Platform",
  description: "A complete, modern university learning platform. Find, organize, view, and download educational materials by university, degree, major, year, semester, and subject.",
  keywords: ["e-learning", "university", "Morocco", "education", "academic"],
  icons: {
    icon: "/logo.svg",
  },
};

// Inline script that runs BEFORE React hydration to strip attributes injected by
// browser extensions (e.g. `bis_skin_checked`, `bis_status`, `bis_frame_id`).
// These cause hydration mismatches because React sees attributes it didn't render.
// The MutationObserver keeps stripping them as the extension re-adds them.
const extensionAttrStripper = `(function(){
  if (typeof window === 'undefined') return;
  var STRIP = /^bis_/i;
  function clean(node){
    if (!node || !node.attributes) return;
    var attrs = Array.prototype.slice.call(node.attributes);
    for (var i = 0; i < attrs.length; i++) {
      if (STRIP.test(attrs[i].name)) {
        node.removeAttribute(attrs[i].name);
      }
    }
  }
  function walk(root){
    if (!root) return;
    clean(root);
    if (root.querySelectorAll) {
      var nodes = root.querySelectorAll('*');
      for (var i = 0; i < nodes.length; i++) clean(nodes[i]);
    }
  }
  walk(document.documentElement);
  if (typeof MutationObserver !== 'undefined') {
    var obs = new MutationObserver(function(muts){
      for (var i = 0; i < muts.length; i++) {
        var m = muts[i];
        if (m.type === 'attributes' && m.attributeName && STRIP.test(m.attributeName)) {
          m.target.removeAttribute(m.attributeName);
        } else if (m.type === 'childList' && m.addedNodes) {
          for (var j = 0; j < m.addedNodes.length; j++) {
            walk(m.addedNodes[j]);
          }
        }
      }
    });
    try {
      obs.observe(document.documentElement, { subtree: true, attributes: true, childList: true });
    } catch (e) {}
  }
})();`;

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: extensionAttrStripper }} />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${cairo.variable} antialiased bg-background text-foreground`}
        suppressHydrationWarning
      >
        <Providers>
          {children}
          <SonnerToaster position="top-center" />
        </Providers>
      </body>
    </html>
  );
}
