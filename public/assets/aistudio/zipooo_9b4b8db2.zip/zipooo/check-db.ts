import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const [u, univ, lessons, majors, profs] = await Promise.all([
  db.user.count(),
  db.university.count(),
  db.lesson.count(),
  db.major.count(),
  db.professor.count(),
]);
console.log({users: u, universities: univ, lessons, majors, professors: profs});
await db.$disconnect();
