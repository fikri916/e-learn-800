import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
// Clear all tables (in FK order, children first)
const order = ["adDismissal","ad","auditLog","recentlyViewed","favorite","adDismissal","notificationDismissal","notification","lessonContentBlock","lesson","mediaFile","professor","subject","semester","academicYear","major","degreeUniversity","degreeLevel","faculty","university","websiteSettings","user","account","session","verificationToken"];
for (const t of order) {
  try { await (db as any)[t].deleteMany({}); } catch {}
}
console.log("Cleared all tables");
await db.$disconnect();
