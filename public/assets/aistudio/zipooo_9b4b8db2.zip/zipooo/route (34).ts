import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Global search — searches universities, degrees, majors, subjects, lessons (published only)
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const q = (sp.get("q") || "").trim().toLowerCase();
  if (!q || q.length < 1) return NextResponse.json({ results: [] });

  const [universities, majors, subjects, lessons] = await Promise.all([
    db.university.findMany({
      where: {
        published: true,
        OR: [{ name: { contains: q } }, { nameAr: { contains: q } }, { nameFr: { contains: q } }],
      },
      take: 10,
      select: { id: true, name: true, nameAr: true, nameFr: true, city: true, logo: true },
    }),
    db.major.findMany({
      where: {
        published: true,
        OR: [{ name: { contains: q } }, { nameAr: { contains: q } }, { nameFr: { contains: q } }],
      },
      take: 10,
      select: { id: true, name: true, nameAr: true, nameFr: true, universityId: true, degreeLevelId: true },
    }),
    db.subject.findMany({
      where: {
        published: true,
        OR: [{ name: { contains: q } }, { nameAr: { contains: q } }, { nameFr: { contains: q } }],
      },
      take: 10,
      select: { id: true, name: true, nameAr: true, nameFr: true, semesterId: true },
    }),
    db.lesson.findMany({
      where: {
        status: "PUBLISHED",
        OR: [{ title: { contains: q } }, { titleAr: { contains: q } }, { titleFr: { contains: q } }, { description: { contains: q } }],
      },
      take: 20,
      select: { id: true, title: true, titleAr: true, titleFr: true, description: true, subjectId: true, subject: { select: { id: true, name: true, semester: { select: { id: true, academicYear: { select: { id: true, major: { select: { id: true, universityId: true, degreeLevelId: true } } } } } } } } },
    }),
  ]);

  return NextResponse.json({
    results: {
      universities: universities.map((u) => ({ type: "university", ...u })),
      majors: majors.map((m) => ({ type: "major", ...m })),
      subjects: subjects.map((s) => ({ type: "subject", ...s })),
      lessons: lessons.map((l) => ({ type: "lesson", ...l })),
    },
  });
}
