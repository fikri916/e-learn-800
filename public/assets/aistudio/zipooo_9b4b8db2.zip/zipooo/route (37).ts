// Public academic navigation data — universities (optionally filtered by student profile)
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const universities = await db.university.findMany({
    where: { published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: {
      id: true, name: true, nameAr: true, nameFr: true,
      description: true, descriptionAr: true, descriptionFr: true,
      city: true, logo: true, coverImage: true,
      degreeUniversities: { select: { degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true } } } },
    },
  });
  // Flatten degrees
  const out = universities.map((u) => ({
    ...u,
    degrees: u.degreeUniversities.map((du) => du.degreeLevel),
    degreeUniversities: undefined,
  }));
  return NextResponse.json({ universities: out });
}
