import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/public/faculties?universityId=...
// Returns published faculties for the given university.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const universityId = sp.get("universityId");
  if (!universityId) return NextResponse.json({ faculties: [] });
  const faculties = await db.faculty.findMany({
    where: { universityId, published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: {
      id: true, name: true, nameAr: true, nameFr: true,
      _count: { select: { majors: { where: { published: true } } } },
    },
  });
  return NextResponse.json({ faculties });
}
