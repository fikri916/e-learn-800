import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// GET recently-viewed lessons for current student
export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const recent = await db.recentlyViewed.findMany({
    where: { userId: (session.user as any).id },
    orderBy: { viewedAt: "desc" },
    take: 12,
    include: {
      lesson: {
        select: {
          id: true, title: true, titleAr: true, titleFr: true,
          description: true, thumbnail: true,
          subject: { select: { id: true, name: true } },
        },
      },
    },
  });
  return NextResponse.json({ recentlyViewed: recent });
}
