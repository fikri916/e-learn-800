import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET() {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const media = await db.mediaFile.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
  });
  return NextResponse.json({ media });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const media = await db.mediaFile.findUnique({ where: { id } });
  if (!media) return NextResponse.json({ error: "not found" }, { status: 404 });
  await db.mediaFile.delete({ where: { id } });
  try {
    const fs = await import("fs/promises");
    const path = await import("path");
    await fs.unlink(path.join(process.cwd(), "public", media.path));
  } catch {}
  await audit((session.user as any).id, "MEDIA_DELETE", "MediaFile", id, media.filename);
  return NextResponse.json({ ok: true });
}
