// POST /api/admin/backup/restore — accepts a JSON backup file (multipart form-data, field name "file")
// and restores all tables. Deletes all existing rows first (in reverse FK order), then inserts
// the backup rows in the correct parent→child order so FK relationships resolve. Also writes
// media file blobs back to disk.

import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";
import { writeFile, mkdir } from "fs/promises";
import path from "path";

// Tables to wipe + restore, in the order they need to be inserted (parents first).
// SQLite doesn't enforce FK constraints by default with Prisma, but we still want
// a sensible order so reads after restore see consistent data.
const TABLE_ORDER: Array<{ name: string; model: any }> = [
  { name: "users", model: db.user },
  { name: "universities", model: db.university },
  { name: "faculties", model: db.faculty },
  { name: "degreeLevels", model: db.degreeLevel },
  { name: "degreeUniversities", model: db.degreeUniversity },
  { name: "majors", model: db.major },
  { name: "academicYears", model: db.academicYear },
  { name: "semesters", model: db.semester },
  { name: "subjects", model: db.subject },
  { name: "professors", model: db.professor },
  { name: "lessons", model: db.lesson },
  { name: "lessonContentBlocks", model: db.lessonContentBlock },
  { name: "mediaFiles", model: db.mediaFile },
  { name: "favorites", model: db.favorite },
  { name: "recentlyViewed", model: db.recentlyViewed },
  { name: "notifications", model: db.notification },
  { name: "notificationDismissals", model: db.notificationDismissal },
  { name: "ads", model: db.ad },
  { name: "adDismissals", model: db.adDismissal },
  { name: "websiteSettings", model: db.websiteSettings },
  { name: "auditLogs", model: db.auditLog },
];

// Reverse order for deletion (children first so no FK references remain)
const DELETE_ORDER = [...TABLE_ORDER].reverse();

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  try {
    const formData = await req.formData();
    const file = formData.get("file");
    if (!file || !(file instanceof File)) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }
    const text = await file.text();
    let backup: any;
    try {
      backup = JSON.parse(text);
    } catch {
      return NextResponse.json({ error: "Invalid backup file (not valid JSON)" }, { status: 400 });
    }
    if (!backup || !backup.tables) {
      return NextResponse.json({ error: "Invalid backup file (missing 'tables' field)" }, { status: 400 });
    }
    const t = backup.tables;
    const restored: Record<string, number> = {};
    const errors: string[] = [];

    // === Write media file blobs back to disk ===
    if (backup.mediaBlobs && typeof backup.mediaBlobs === "object") {
      const uploadDir = path.join(process.cwd(), "public", "uploads");
      await mkdir(uploadDir, { recursive: true });
      for (const [relPath, b64] of Object.entries(backup.mediaBlobs)) {
        try {
          const abs = path.join(process.cwd(), "public", relPath);
          await mkdir(path.dirname(abs), { recursive: true });
          await writeFile(abs, Buffer.from(b64 as string, "base64"));
        } catch (e: any) {
          errors.push(`Failed to restore file ${relPath}: ${e.message}`);
        }
      }
    }

    // === Restore DB tables (delete all → insert from backup) ===
    for (const { name, model } of DELETE_ORDER) {
      try {
        await model.deleteMany({});
      } catch (e: any) {
        errors.push(`Failed to clear ${name}: ${e.message}`);
      }
    }
    for (const { name, model } of TABLE_ORDER) {
      const rows = t[name];
      if (!Array.isArray(rows) || rows.length === 0) {
        restored[name] = 0;
        continue;
      }
      try {
        // Prisma SQLite has a 999-parameter limit per query — chunk into batches
        // by row count to stay under it. The number depends on the column count,
        // but chunking at 50 rows is safe for any reasonable schema.
        const CHUNK = 50;
        let total = 0;
        for (let i = 0; i < rows.length; i += CHUNK) {
          const slice = rows.slice(i, i + CHUNK);
          try {
            await model.createMany({ data: slice, skipDuplicates: true });
            total += slice.length;
          } catch (e: any) {
            // If createMany fails (e.g., unique constraint), fall back to per-row upsert
            for (const row of slice) {
              try {
                await model.upsert({
                  where: { id: row.id },
                  create: row,
                  update: row,
                });
                total++;
              } catch (e2: any) {
                errors.push(`Failed to upsert row ${row.id} in ${name}: ${e2.message}`);
              }
            }
          }
        }
        restored[name] = total;
      } catch (e: any) {
        errors.push(`Failed to restore ${name}: ${e.message}`);
        restored[name] = 0;
      }
    }

    await audit((session.user as any).id, "BACKUP_RESTORE", "Database", null, `Restored ${Object.values(restored).reduce((a, b) => a + b, 0)} rows total`);

    return NextResponse.json({
      ok: true,
      restored,
      errors,
      mediaFilesWritten: backup.mediaBlobs ? Object.keys(backup.mediaBlobs).length : 0,
      skippedFiles: backup.skippedFiles || [],
    });
  } catch (e: any) {
    return NextResponse.json({ error: "server_error", message: String(e?.message || e) }, { status: 500 });
  }
}
