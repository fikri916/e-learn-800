import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const universityId = sp.get("universityId") || undefined;
  const degreeLevelId = sp.get("degreeLevelId") || undefined;
  const facultyId = sp.get("facultyId") || undefined;
  const majors = await db.major.findMany({
    where: { ...(universityId ? { universityId } : {}), ...(degreeLevelId ? { degreeLevelId } : {}), ...(facultyId ? { facultyId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: {
      university: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      faculty: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      _count: { select: { lessons: true, academicYears: true } },
    },
  });
  return NextResponse.json({ majors });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.universityId || !body.degreeLevelId) return NextResponse.json({ error: "university+degree required" }, { status: 400 });
  const m = await db.major.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      description: body.description || null,
      descriptionAr: body.descriptionAr || null,
      descriptionFr: body.descriptionFr || null,
      coverImage: body.coverImage || null,
      universityId: body.universityId,
      degreeLevelId: body.degreeLevelId,
      facultyId: body.facultyId || null,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "MAJOR_CREATE", "Major", m.id, m.name);
  return NextResponse.json({ ok: true, major: m });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "description", "descriptionAr", "descriptionFr", "coverImage", "universityId", "degreeLevelId", "facultyId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const m = await db.major.update({ where: { id }, data });
  await audit((session.user as any).id, "MAJOR_UPDATE", "Major", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, major: m });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.major.delete({ where: { id } });
  await audit((session.user as any).id, "MAJOR_DELETE", "Major", id, null);
  return NextResponse.json({ ok: true });
}
