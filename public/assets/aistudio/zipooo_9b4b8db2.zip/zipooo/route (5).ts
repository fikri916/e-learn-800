import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const universityId = sp.get("universityId") || undefined;
  const faculties = await db.faculty.findMany({
    where: { ...(universityId ? { universityId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: { university: { select: { id: true, name: true, nameAr: true, nameFr: true } } },
  });
  return NextResponse.json({ faculties });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.universityId) return NextResponse.json({ error: "universityId required" }, { status: 400 });
  const f = await db.faculty.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      universityId: body.universityId,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "FACULTY_CREATE", "Faculty", f.id, f.name);
  return NextResponse.json({ ok: true, faculty: f });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "universityId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const f = await db.faculty.update({ where: { id }, data });
  await audit((session.user as any).id, "FACULTY_UPDATE", "Faculty", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, faculty: f });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.faculty.delete({ where: { id } });
  await audit((session.user as any).id, "FACULTY_DELETE", "Faculty", id, null);
  return NextResponse.json({ ok: true });
}
