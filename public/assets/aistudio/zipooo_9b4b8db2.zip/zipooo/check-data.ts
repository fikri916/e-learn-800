import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const subjects = await db.subject.findMany({ select: { id: true, name: true, semesterId: true } });
console.log("Subjects:", JSON.stringify(subjects, null, 2));
const lessons = await db.lesson.findMany({ select: { id: true, title: true, subjectId: true, status: true } });
console.log("Lessons:", JSON.stringify(lessons, null, 2));
await db.$disconnect();
