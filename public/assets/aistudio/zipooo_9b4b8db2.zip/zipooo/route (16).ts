import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET /api/admin/users — list users with filters
export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const search = sp.get("q") || undefined;
  const role = sp.get("role") || undefined;
  const status = sp.get("status") || undefined;
  const universityId = sp.get("universityId") || undefined;
  const users = await db.user.findMany({
    where: {
      ...(search ? { OR: [{ name: { contains: search } }, { email: { contains: search } }] } : {}),
      ...(role ? { role } : {}),
      ...(status ? { status } : {}),
      ...(universityId ? { universityId } : {}),
    },
    orderBy: { createdAt: "desc" },
    take: 500,
    select: {
      id: true, name: true, email: true, role: true, status: true, createdAt: true,
      university: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      degreeLevel: { select: { id: true, name: true } },
      major: { select: { id: true, name: true } },
      academicYear: { select: { id: true, name: true } },
    },
  });
  return NextResponse.json({ users });
}

// PATCH /api/admin/users — update role/status/academic profile
export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, role, status, name, universityId, degreeLevelId, majorId, academicYearId } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  // Safety: prevent last admin from being demoted/suspended
  if (role && role !== "ADMIN") {
    const target = await db.user.findUnique({ where: { id } });
    if (target?.role === "ADMIN") {
      const adminCount = await db.user.count({ where: { role: "ADMIN", status: "ACTIVE" } });
      if (adminCount <= 1) {
        return NextResponse.json({ error: "last_admin" }, { status: 400 });
      }
    }
  }
  const before = await db.user.findUnique({ where: { id } });
  const updated = await db.user.update({
    where: { id },
    data: {
      ...(role ? { role } : {}),
      ...(status ? { status } : {}),
      ...(name ? { name } : {}),
      universityId: universityId === "" ? null : universityId,
      degreeLevelId: degreeLevelId === "" ? null : degreeLevelId,
      majorId: majorId === "" ? null : majorId,
      academicYearId: academicYearId === "" ? null : academicYearId,
    },
  });
  await audit((session.user as any).id, "USER_UPDATE", "User", id, JSON.stringify({ before: { role: before?.role, status: before?.status }, after: { role: updated.role, status: updated.status } }));
  return NextResponse.json({ ok: true, user: updated });
}

// DELETE /api/admin/users?id=...
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  // Prevent self-delete if last admin
  const target = await db.user.findUnique({ where: { id } });
  if (target?.role === "ADMIN") {
    const adminCount = await db.user.count({ where: { role: "ADMIN", status: "ACTIVE" } });
    if (adminCount <= 1) {
      return NextResponse.json({ error: "last_admin" }, { status: 400 });
    }
  }
  await db.user.delete({ where: { id } });
  await audit((session.user as any).id, "USER_DELETE", "User", id, null);
  return NextResponse.json({ ok: true });
}
