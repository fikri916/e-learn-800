import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// Get active notifications for current user (based on audience targeting)
export async function GET() {
  const session = await getServerSession(authOptions);
  const now = new Date();
  // All PUBLISHED notifications whose time window is valid
  const all = await db.notification.findMany({
    where: {
      status: "PUBLISHED",
      AND: [
        { OR: [{ publishAt: null }, { publishAt: { lte: now } }] },
        { OR: [{ expiresAt: null }, { expiresAt: { gte: now } }] },
      ],
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  // Filter by audience
  let userId: string | null = null;
  let user: any = null;
  if (session) {
    userId = (session.user as any).id;
    user = await db.user.findUnique({
      where: { id: userId },
      select: { universityId: true, degreeLevelId: true, majorId: true, academicYearId: true },
    });
  }
  const filtered = all.filter((n) => {
    if (n.audienceType === "ALL") return true;
    if (!userId || !user) return false;
    if (n.audienceType === "USERS") {
      const ids: string[] = n.targetIds ? JSON.parse(n.targetIds) : [];
      return ids.includes(userId);
    }
    if (!n.targetIds) return false;
    const ids: string[] = JSON.parse(n.targetIds);
    if (n.audienceType === "UNIVERSITY") return user.universityId && ids.includes(user.universityId);
    if (n.audienceType === "DEGREE") return user.degreeLevelId && ids.includes(user.degreeLevelId);
    if (n.audienceType === "MAJOR") return user.majorId && ids.includes(user.majorId);
    if (n.audienceType === "YEAR") return user.academicYearId && ids.includes(user.academicYearId);
    return false;
  });

  // For students: filter dismissed unless showEveryVisit
  let dismissed = new Set<string>();
  if (userId) {
    const ds = await db.notificationDismissal.findMany({
      where: { userId },
      select: { notificationId: true },
    });
    dismissed = new Set(ds.map((d) => d.notificationId));
  }
  const visible = filtered.filter((n) => n.showEveryVisit || !dismissed.has(n.id));

  return NextResponse.json({ notifications: visible });
}

// POST dismiss a notification for current user
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions);
  if (!session || (session.user as any).role !== "STUDENT") {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }
  const { notificationId } = await req.json();
  if (!notificationId) return NextResponse.json({ error: "id required" }, { status: 400 });
  const userId = (session.user as any).id;
  const existing = await db.notificationDismissal.findUnique({
    where: { userId_notificationId: { userId, notificationId } },
  });
  if (!existing) {
    await db.notificationDismissal.create({ data: { userId, notificationId } });
  }
  return NextResponse.json({ ok: true });
}
