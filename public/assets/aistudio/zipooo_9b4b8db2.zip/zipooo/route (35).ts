import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Get semesters for an academic year
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const academicYearId = sp.get("academicYearId");
  if (!academicYearId) return NextResponse.json({ semesters: [] });
  const semesters = await db.semester.findMany({
    where: { academicYearId, published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: { id: true, name: true, nameAr: true, nameFr: true },
  });
  return NextResponse.json({ semesters });
}
