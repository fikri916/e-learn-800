import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET lessons (filterable)
export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const where: any = {};
  for (const k of ["universityId", "degreeLevelId", "majorId", "academicYearId", "semesterId", "subjectId", "status"]) {
    const v = sp.get(k);
    if (v) where[k] = v;
  }
  const q = sp.get("q");
  if (q) where.OR = [{ title: { contains: q } }, { titleAr: { contains: q } }, { titleFr: { contains: q } }];
  const lessons = await db.lesson.findMany({
    where,
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    take: 300,
    include: {
      university: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      major: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      academicYear: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      semester: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      subject: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      professor: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      _count: { select: { contentBlocks: true } },
    },
  });
  return NextResponse.json({ lessons });
}

// POST create lesson
export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();

  // Validate assignment chain: subject belongs to semester, etc.
  const valid = await validateChain(body);
  if (!valid.ok) return NextResponse.json({ error: valid.error }, { status: 400 });

  const lesson = await db.lesson.create({
    data: {
      title: body.title,
      titleAr: body.titleAr || null,
      titleFr: body.titleFr || null,
      description: body.description || null,
      descriptionAr: body.descriptionAr || null,
      descriptionFr: body.descriptionFr || null,
      thumbnail: body.thumbnail || null,
      status: body.status || "DRAFT",
      order: Number(body.order ?? 0),
      universityId: body.universityId,
      degreeLevelId: body.degreeLevelId,
      majorId: body.majorId,
      academicYearId: body.academicYearId,
      semesterId: body.semesterId,
      subjectId: body.subjectId,
      professorId: body.professorId || null,
      contentBlocks: body.contentBlocks?.length ? {
        create: body.contentBlocks.map((b: any, i: number) => ({
          order: b.order ?? i,
          type: b.type,
          title: b.title || null,
          content: b.content || null,
          mediaPath: b.mediaPath || null,
          mediaPaths: b.mediaPaths ? JSON.stringify(b.mediaPaths) : null,
          downloadable: b.downloadable ?? true,
        })),
      } : undefined,
    },
    include: { contentBlocks: true },
  });
  await audit((session.user as any).id, "LESSON_CREATE", "Lesson", lesson.id, lesson.title);
  return NextResponse.json({ ok: true, lesson });
}

// PATCH update lesson (including moving to another subject)
export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  // Validate chain if assignment changed
  if (rest.subjectId || rest.semesterId || rest.academicYearId || rest.majorId || rest.degreeLevelId || rest.universityId) {
    const merged = { ...rest, id };
    const valid = await validateChain(merged);
    if (!valid.ok) return NextResponse.json({ error: valid.error }, { status: 400 });
  }

  const data: any = {};
  for (const k of ["title", "titleAr", "titleFr", "description", "descriptionAr", "descriptionFr", "thumbnail", "universityId", "degreeLevelId", "majorId", "academicYearId", "semesterId", "subjectId", "professorId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("status" in rest) data.status = rest.status;
  if ("order" in rest) data.order = Number(rest.order);

  const lesson = await db.lesson.update({ where: { id }, data, include: { contentBlocks: true } });

  // Replace content blocks if provided
  if (Array.isArray(rest.contentBlocks)) {
    await db.lessonContentBlock.deleteMany({ where: { lessonId: id } });
    if (rest.contentBlocks.length) {
      await db.lessonContentBlock.createMany({
        data: rest.contentBlocks.map((b: any, i: number) => ({
          lessonId: id,
          order: b.order ?? i,
          type: b.type,
          title: b.title || null,
          content: b.content || null,
          mediaPath: b.mediaPath || null,
          mediaPaths: b.mediaPaths ? JSON.stringify(b.mediaPaths) : null,
          downloadable: b.downloadable ?? true,
        })),
      });
    }
    // refetch blocks
    const blocks = await db.lessonContentBlock.findMany({ where: { lessonId: id }, orderBy: { order: "asc" } });
    lesson.contentBlocks = blocks;
  }
  await audit((session.user as any).id, "LESSON_UPDATE", "Lesson", id, JSON.stringify({ title: data.title, status: data.status }));
  return NextResponse.json({ ok: true, lesson });
}

// DELETE lesson
export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.lesson.delete({ where: { id } });
  await audit((session.user as any).id, "LESSON_DELETE", "Lesson", id, null);
  return NextResponse.json({ ok: true });
}

// Helper — validate that the selected subject belongs to the semester, year, major, degree, university
async function validateChain(body: any): Promise<{ ok: boolean; error?: string }> {
  if (!body.universityId || !body.degreeLevelId || !body.majorId || !body.academicYearId || !body.semesterId || !body.subjectId) {
    return { ok: false, error: "all academic fields are required" };
  }
  // subject -> semester
  const subject = await db.subject.findUnique({ where: { id: body.subjectId }, select: { semesterId: true } });
  if (!subject) return { ok: false, error: "subject not found" };
  if (subject.semesterId !== body.semesterId) return { ok: false, error: "subject does not belong to the selected semester" };
  // semester -> academicYear
  const semester = await db.semester.findUnique({ where: { id: body.semesterId }, select: { academicYearId: true } });
  if (!semester) return { ok: false, error: "semester not found" };
  if (semester.academicYearId !== body.academicYearId) return { ok: false, error: "semester does not belong to the selected year" };
  // academicYear -> major + degreeLevel
  const year = await db.academicYear.findUnique({ where: { id: body.academicYearId }, select: { majorId: true, degreeLevelId: true } });
  if (!year) return { ok: false, error: "year not found" };
  if (year.majorId !== body.majorId) return { ok: false, error: "year does not belong to the selected major" };
  if (year.degreeLevelId !== body.degreeLevelId) return { ok: false, error: "year does not belong to the selected degree" };
  // major -> university + degreeLevel
  const major = await db.major.findUnique({ where: { id: body.majorId }, select: { universityId: true, degreeLevelId: true } });
  if (!major) return { ok: false, error: "major not found" };
  if (major.universityId !== body.universityId) return { ok: false, error: "major does not belong to the selected university" };
  if (major.degreeLevelId !== body.degreeLevelId) return { ok: false, error: "major does not belong to the selected degree" };
  // professor -> semester (if provided)
  if (body.professorId) {
    const prof = await db.professor.findUnique({ where: { id: body.professorId }, select: { semesterId: true } });
    if (!prof) return { ok: false, error: "professor not found" };
    if (prof.semesterId !== body.semesterId) return { ok: false, error: "professor does not belong to the selected semester" };
  }
  return { ok: true };
}
