import { PrismaClient } from "@prisma/client";
const db = new PrismaClient();
const logs = await db.auditLog.findMany({ take: 5 });
console.log("Audit log count:", logs.length);
console.log(JSON.stringify(logs, null, 2));
await db.$disconnect();
