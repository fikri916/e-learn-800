// Public website settings for branding + homepage
import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const settings = await db.websiteSettings.findFirst();
  return NextResponse.json({ settings: settings || null });
}
