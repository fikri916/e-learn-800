import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

// GET /api/admin/ads?type=POPUP|HERO_BANNER
export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const type = sp.get("type") || undefined;
  const ads = await db.ad.findMany({
    where: { ...(type ? { type } : {}) },
    orderBy: [{ order: "asc" }, { createdAt: "desc" }],
    take: 200,
    include: { _count: { select: { dismissals: true } } },
  });
  return NextResponse.json({ ads });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.title || !body.type) return NextResponse.json({ error: "title and type required" }, { status: 400 });
  const ad = await db.ad.create({
    data: {
      title: body.title,
      content: body.content || null,
      type: body.type,
      imageUrl: body.imageUrl || null,
      imageMobile: body.imageMobile || null,
      imageDesktop: body.imageDesktop || null,
      linkUrl: body.linkUrl || null,
      linkTarget: body.linkTarget || "_blank",
      audienceType: body.audienceType || "ALL",
      targetIds: body.targetIds ? JSON.stringify(body.targetIds) : null,
      dismissible: body.dismissible ?? true,
      showEveryLogin: !!body.showEveryLogin,
      status: body.status || "DRAFT",
      publishAt: body.publishAt ? new Date(body.publishAt) : null,
      expiresAt: body.expiresAt ? new Date(body.expiresAt) : null,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "AD_CREATE", "Ad", ad.id, ad.title);
  return NextResponse.json({ ok: true, ad });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["title", "content", "type", "imageUrl", "imageMobile", "imageDesktop", "linkUrl", "linkTarget", "audienceType"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("dismissible" in rest) data.dismissible = !!rest.dismissible;
  if ("showEveryLogin" in rest) data.showEveryLogin = !!rest.showEveryLogin;
  if ("status" in rest) data.status = rest.status;
  if ("order" in rest) data.order = Number(rest.order);
  if (rest.targetIds !== undefined) data.targetIds = rest.targetIds ? JSON.stringify(rest.targetIds) : null;
  if (rest.publishAt !== undefined) data.publishAt = rest.publishAt ? new Date(rest.publishAt) : null;
  if (rest.expiresAt !== undefined) data.expiresAt = rest.expiresAt ? new Date(rest.expiresAt) : null;
  const ad = await db.ad.update({ where: { id }, data });
  await audit((session.user as any).id, "AD_UPDATE", "Ad", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, ad });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.ad.delete({ where: { id } });
  await audit((session.user as any).id, "AD_DELETE", "Ad", id, null);
  return NextResponse.json({ ok: true });
}
