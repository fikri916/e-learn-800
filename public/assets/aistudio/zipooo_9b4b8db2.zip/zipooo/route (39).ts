import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Get academic years for a major+degree
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const majorId = sp.get("majorId");
  const degreeLevelId = sp.get("degreeLevelId");
  if (!majorId || !degreeLevelId) return NextResponse.json({ years: [] });
  const years = await db.academicYear.findMany({
    where: { majorId, degreeLevelId, published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: { id: true, name: true, nameAr: true, nameFr: true },
  });
  return NextResponse.json({ years });
}
