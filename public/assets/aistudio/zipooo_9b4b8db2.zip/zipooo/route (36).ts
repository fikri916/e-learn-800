import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// Get published subjects for a semester.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const semesterId = sp.get("semesterId");
  if (!semesterId) return NextResponse.json({ subjects: [] });
  const subjects = await db.subject.findMany({
    where: { semesterId, published: true },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    select: {
      id: true, name: true, nameAr: true, nameFr: true,
      description: true, descriptionAr: true, descriptionFr: true, coverImage: true,
      _count: { select: { lessons: { where: { status: "PUBLISHED" } } } },
    },
  });
  return NextResponse.json({ subjects });
}
