import { NextRequest, NextResponse } from "next/server";
import { requireAdmin, audit } from "@/lib/admin-guard";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const majorId = sp.get("majorId") || undefined;
  const years = await db.academicYear.findMany({
    where: { ...(majorId ? { majorId } : {}) },
    orderBy: [{ order: "asc" }, { name: "asc" }],
    include: {
      major: { select: { id: true, name: true, university: { select: { id: true, name: true } }, degreeLevel: { select: { id: true, name: true } } } },
      _count: { select: { semesters: true, lessons: true } },
    },
  });
  return NextResponse.json({ years });
}

export async function POST(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  if (!body.majorId || !body.degreeLevelId) return NextResponse.json({ error: "major+degree required" }, { status: 400 });
  const y = await db.academicYear.create({
    data: {
      name: body.name,
      nameAr: body.nameAr || null,
      nameFr: body.nameFr || null,
      majorId: body.majorId,
      degreeLevelId: body.degreeLevelId,
      published: !!body.published,
      order: Number(body.order ?? 0),
    },
  });
  await audit((session.user as any).id, "YEAR_CREATE", "AcademicYear", y.id, y.name);
  return NextResponse.json({ ok: true, year: y });
}

export async function PATCH(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const body = await req.json();
  const { id, ...rest } = body;
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const data: any = {};
  for (const k of ["name", "nameAr", "nameFr", "majorId", "degreeLevelId"]) {
    if (k in rest) data[k] = rest[k] === "" ? null : rest[k];
  }
  if ("published" in rest) data.published = !!rest.published;
  if ("order" in rest) data.order = Number(rest.order);
  const y = await db.academicYear.update({ where: { id }, data });
  await audit((session.user as any).id, "YEAR_UPDATE", "AcademicYear", id, JSON.stringify(data));
  return NextResponse.json({ ok: true, year: y });
}

export async function DELETE(req: NextRequest) {
  const session = await requireAdmin();
  if (!session) return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.academicYear.delete({ where: { id } });
  await audit((session.user as any).id, "YEAR_DELETE", "AcademicYear", id, null);
  return NextResponse.json({ ok: true });
}
