// Public registration — creates a STUDENT account
import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2),
  email: z.string().email(),
  password: z.string().min(8),
  confirmPassword: z.string().min(8),
  universityId: z.string().optional(),
  degreeLevelId: z.string().optional(),
  majorId: z.string().optional(),
  academicYearId: z.string().optional(),
}).refine((d) => d.password === d.confirmPassword, { message: "password_mismatch" });

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      const issue = parsed.error.issues[0]?.message || "invalid";
      return NextResponse.json({ error: issue }, { status: 400 });
    }
    const { name, email, password, universityId, degreeLevelId, majorId, academicYearId } = parsed.data;
    const emailLc = email.toLowerCase().trim();
    const existing = await db.user.findUnique({ where: { email: emailLc } });
    if (existing) return NextResponse.json({ error: "exists" }, { status: 409 });
    const passwordHash = await bcrypt.hash(password, 10);
    await db.user.create({
      data: {
        name,
        email: emailLc,
        passwordHash,
        role: "STUDENT",
        status: "ACTIVE",
        universityId: universityId || null,
        degreeLevelId: degreeLevelId || null,
        majorId: majorId || null,
        academicYearId: academicYearId || null,
      },
    });
    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ error: "server_error", message: String(e?.message || e) }, { status: 500 });
  }
}
