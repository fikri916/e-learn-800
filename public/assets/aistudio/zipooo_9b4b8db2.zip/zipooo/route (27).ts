import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";

// Get a single lesson by ID (with full academic context + content blocks)
// Also records recently-viewed entry if a student session is present.
export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const id = sp.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });

  const lesson = await db.lesson.findUnique({
    where: { id },
    include: {
      university: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      degreeLevel: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      major: { select: { id: true, name: true, nameAr: true, nameFr: true, facultyId: true } },
      academicYear: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      semester: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      subject: { select: { id: true, name: true, nameAr: true, nameFr: true } },
      professor: { select: { id: true, name: true, nameAr: true, nameFr: true, bio: true, bioAr: true, bioFr: true, photo: true, email: true } },
      contentBlocks: { orderBy: { order: "asc" } },
    },
  });
  if (!lesson || (lesson.status !== "PUBLISHED")) {
    // Allow admins to preview unpublished too
    const session = await getServerSession(authOptions);
    if (!session || (session.user as any).role !== "ADMIN") {
      return NextResponse.json({ error: "not_found" }, { status: 404 });
    }
  }

  // Get sibling lessons (prev/next)
  const siblings = await db.lesson.findMany({
    where: { subjectId: lesson.subjectId, status: "PUBLISHED" },
    orderBy: [{ order: "asc" }, { createdAt: "asc" }],
    select: { id: true, title: true, titleAr: true, titleFr: true, order: true, createdAt: true },
  });
  const idx = siblings.findIndex((s) => s.id === lesson.id);
  const prev = idx > 0 ? siblings[idx - 1] : null;
  const next = idx < siblings.length - 1 ? siblings[idx + 1] : null;

  // Related lessons (same subject, exclude current)
  const related = siblings.filter((s) => s.id !== lesson.id).slice(0, 5);

  // Record recently viewed for logged-in student
  const session = await getServerSession(authOptions);
  if (session && (session.user as any).role === "STUDENT") {
    try {
      const userId = (session.user as any).id;
      // upsert: only one entry per user-lesson; bump viewedAt
      const existing = await db.recentlyViewed.findUnique({
        where: { userId_lessonId: { userId, lessonId: lesson.id } },
      });
      if (existing) {
        await db.recentlyViewed.update({
          where: { id: existing.id },
          data: { viewedAt: new Date() },
        });
      } else {
        await db.recentlyViewed.create({ data: { userId, lessonId: lesson.id } });
      }
    } catch {}
  }

  // Favorite state
  let isFavorite = false;
  if (session && (session.user as any).role === "STUDENT") {
    const fav = await db.favorite.findUnique({
      where: { userId_lessonId: { userId: (session.user as any).id, lessonId: lesson.id } },
    });
    isFavorite = !!fav;
  }

  return NextResponse.json({ lesson, prev, next, related, isFavorite });
}
